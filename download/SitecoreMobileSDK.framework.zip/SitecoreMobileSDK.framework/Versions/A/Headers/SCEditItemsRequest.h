#import <SitecoreMobileSDK/SCItemsReaderRequest.h>

//STODO! document this file
@interface SCEditItemsRequest : SCItemsReaderRequest

@property ( nonatomic, strong ) NSDictionary* fieldsRawValuesByName;

@end

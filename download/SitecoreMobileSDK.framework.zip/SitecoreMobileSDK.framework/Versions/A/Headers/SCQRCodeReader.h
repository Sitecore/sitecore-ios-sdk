
#import <SitecoreMobileSDK/SCQRCodeReaderView.h>
#import <SitecoreMobileSDK/SCQRCodeReaderViewDelegate.h>
